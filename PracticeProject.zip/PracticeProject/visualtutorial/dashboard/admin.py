from django.contrib import admin
from . models import MovieData
 
# Register your models here.
admin.site.register(MovieData)
